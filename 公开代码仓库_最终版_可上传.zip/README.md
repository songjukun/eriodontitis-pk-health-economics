# Reproducible periodontal mini-PBPK and cost-effectiveness analysis

This repository contains the final analysis code accompanying the revised manuscript submitted to *International Dental Journal*. It reproduces the mini-PBPK, PK/PD, Markov cost-effectiveness, probabilistic sensitivity, value-of-information, and reviewer-requested robustness analyses.

## Scientific scope

The analysis is a proof-of-concept simulation, not a decision-grade economic evaluation. The economic and PPD-to-pocket-closure components contain explicitly labelled structural or illustrative assumptions. No patient-level dataset is distributed, and independent PK/GCF validation was not possible because an appropriate external patient-level dataset was unavailable.

Two decision lenses are kept separate:

1. A homogeneous representative treated-site reference case, used for main Table 2 and its PSA ICER intervals.
2. A subgroup-prevalence-weighted target-population analysis, used for probability-optimal, EVPI/EVPPI, and EVIC results.

The Table 2 ICER interval is defined as the 2.5th–97.5th percentiles among PSA draws with positive incremental QALYs. The probability of non-positive incremental QALYs is reported separately in `reference_case_PSA_ICER_ranges.csv`.

## Files

- `periodontal_miniPBPK_CEA.py`: canonical executable analysis.
- `periodontal_miniPBPK_CEA.ipynb`: notebook generated from the canonical Python source.
- `requirements.txt`: pinned Python dependencies used for the revision.
- `validate_outputs.py`: checks the reviewer-facing ICER ranges and output contract.
- `make_notebook.py`: regenerates the notebook from the canonical Python source.
- `reference_results/`: compact verified outputs from the final run.
- `RELEASE_CHECKLIST.md`: author actions required before making the repository public.

## Reproduce the analysis

Recommended Python version: 3.12.x. The verified reference run used Python 3.12.14 with the package versions pinned in `requirements.txt`.

```bash
python -m venv .venv
python -m pip install -r requirements.txt
python periodontal_miniPBPK_CEA.py
python validate_outputs.py
```

The analysis uses NumPy's `default_rng` with a global seed of 2024 and 5,000 PSA draws. A complete run writes figures, CSV tables, a Word table file, and `analysis_summary.json` under `reviewer_revision_results/`.

To regenerate the notebook after editing the canonical Python file:

```bash
python make_notebook.py
```

## Expected reviewer-facing PSA ICER results

| Strategy versus SRP | ICER 2.5th–97.5th percentiles, $/QALY | P(incremental QALY ≤ 0) |
|---|---:|---:|
| SRP + Atridox | 1,973–35,076 | 0.019 |
| SRP + PerioChip | 2,022–10,789 | 0.000 |
| SRP + Arestin | 3,482–14,443 | 0.000 |

These intervals are conditional on positive incremental QALYs and should not be interpreted as conventional confidence intervals for a ratio estimator.

## License and citation

No open-source license is asserted in this upload-ready package. The corresponding author should select and add a license before describing the code as open source. Repository URL/DOI and citation metadata must also be added after the public release; see `RELEASE_CHECKLIST.md`.
