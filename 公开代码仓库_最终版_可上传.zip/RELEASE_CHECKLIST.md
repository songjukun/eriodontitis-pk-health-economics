# Public-release checklist

Complete these items before replacing the manuscript's repository placeholder:

- [ ] Confirm that all co-authors approve public code release.
- [ ] Select and add an appropriate software license (for example, MIT, BSD-3-Clause, or GPL-3.0) after checking institutional requirements.
- [ ] Add author and affiliation metadata to a `CITATION.cff` file.
- [ ] Create the public GitHub, GitLab, or institutional repository.
- [ ] Upload the contents of this folder, not the surrounding manuscript/reviewer files.
- [ ] Create an immutable release (for example, `v1.0.0`).
- [ ] Archive that release with Zenodo or an equivalent service if a DOI is required.
- [ ] Replace the repository URL/DOI placeholder in both the manuscript and response letter.
- [ ] Check the public repository from a signed-out browser session.
- [ ] Re-run `python periodontal_miniPBPK_CEA.py` and `python validate_outputs.py` from a fresh clone.

Do not claim that a repository or DOI exists until the public URL resolves.
